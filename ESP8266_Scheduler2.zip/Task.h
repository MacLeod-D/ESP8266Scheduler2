#ifndef TASK_H
#define TASK_H


#define MAXTASKS 7

#include <Arduino.h>
#include "Scheduler.h"

extern "C" {
#include "cont.h"
}

extern char buf[1000];
extern char *bufpt;

enum Stat  { READY, DELAYED, BLOCKED };


class Task {
public:
    Task() {
        int len;
        len=sprintf(bufpt,"Task Construct\n");
        bufpt+=len;
        cont_init(&context);
    }

    char *name=0;;

    void setState(Stat stat) {
        state = stat;
    }

    unsigned long getCalled() {
        return called;
    }

protected:
    virtual void setup() {}
    virtual void loop() {}
    Stat state;

    void delay(unsigned long ms) {
        //if (ms) {
        delay_time = micros();
        delay_us = ms*1000l;
        state=DELAYED;
        //}
        //Yield();
        afterDelay=true;
        cont_yield(&context);
    }


    void delayMicroseconds(unsigned long us) {
        if (us) {
            delay_time = micros();
            delay_us = us;
            state=DELAYED;
        }
        //Yield();
        afterDelay=true;
        cont_yield(&context);
    }





    void Yield() {
        afterDelay=true;
        cont_yield(&context);
    }



    virtual bool shouldRun() {
        unsigned long now = micros();

        //return !delay_us || now >= delay_time + delay_us;

        if (state==DELAYED) {
            if ((now-delay_time)>delay_us) {
                state=READY;
                delay_us=0;
                //afterDelay=true;
            }

        }

        if (state==READY) return true;

        return false;
    }




private:
    friend class SchedulerClass;
    friend void task_runTask();
    int id;
    unsigned long called;
    bool afterDelay=false;
public:
    cont_t context;

    bool setup_done = false;
    unsigned long delay_time;
    unsigned long delay_us;

    typedef  int (Task::*TaskMemFn)() const;

    //TaskMemFn fptr;

//    TaskMemFn getFptr() {
//      fptr = &loopWrapper;
//    }

    //void loopWrapper() const;

    void loopWrapper() {
        if (!setup_done) {
            setup();
            setup_done = true;
        }

        while(1) {

            loop();
            //Yield();
            cont_yield(&context);
        }
    }
};

#endif
