#ifndef SCHEDULER_H
#define SCHEDULER_H

#define LIST_PRIORITY

// #include <Arduino.h>
#include "Task.h"

extern "C" void loop();

extern Task *current;


class SchedulerClass {
public:
    SchedulerClass();

    int start(Task *task, char *nam);
    void begin();
    void block();
    void block(int id);
    void resume(int id);
    unsigned long called;


private:
    friend void task_runTask();

    // class MainTask : public Task {};

    //static Task main;
    //Task *current;
    int frst;
    int rrcnt;
    //static  unsigned int cnt;

};

extern SchedulerClass Scheduler;

#endif
