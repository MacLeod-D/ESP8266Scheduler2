#include "Scheduler.h"

extern "C" {
#include "cont.h"

    void yield();
}

SchedulerClass Scheduler;

//Task SchedulerClass::main;
//Task *SchedulerClass::current = &SchedulerClass::main;


extern char buf[1000];
extern char *bufpt;

int numTasks;
Task *Tasks[7];
Task *current;


SchedulerClass::SchedulerClass() {
    int len;
    len=sprintf(bufpt,"Sched Construct\n");
    bufpt+=len;
    frst=1;
}



int SchedulerClass::start(Task *task, char *nam) {
    Serial.printf("SchedStart %s\n",nam);


    task->name=nam;

    Tasks[numTasks++]=task;

    if (frst) {
        frst=0;
        current=Tasks[0];
    }
    task->state=READY;
    task->id = numTasks-1;

    if (numTasks>=MAXTASKS) {
        Serial .println("\n\nERROR: MAXTASKS too low! \n\n");
        while(1);
    }

    return numTasks-1;
}

unsigned int cnt;

void task_runTask() {
    if (current->name) Serial.printf("*** runTask; %s\n",current->name);
    current->loopWrapper();
}

extern bool critical;
extern long MaxTime;
extern int MaxTask;


typedef  int (Task::*TaskMemFn)(int)  const;


void SchedulerClass::begin() {
    unsigned long lastSystem=millis();
    unsigned long startTask, diffTask;
    while(1) {
        for (int i=0; i<numTasks; i++) {
            current=Tasks[i];

            // run a task:
            if (current->shouldRun())  {
                int lp=0;

                //if (current->id==0) Serial.printf(" [%d] ",lp++);

                startTask=micros();

                cont_run(&current->context, task_runTask);    // yield from loopWrapper
                called++;
                if (current->afterDelay) {
                    current->afterDelay=false;
                    //Serial.println("After Delay");
                    cont_run(&current->context, task_runTask);  // yield from delay, yield
                }

                //if (current->id==0) Serial.printf(" [%d] ",lp++);
                //cont_run(&current->context, current->loopWrapper);  // yield from loopWrapper

                //cont_run(&current->context, &Task::current->loopWrapper);  // yield from loopWrapper

                //cont_run(&current->context, task_runTask);  // get end return of task_runTask;
                current->called++;
                diffTask=micros()-startTask;
                if (diffTask>MaxTime) {
                    MaxTime=diffTask;
                    MaxTask=current->id;
                }


#ifdef LIST_PRIORITY
                break;
#endif


            }

            unsigned long now=millis();         // every 200 ms: yield to system !
            if (!critical) {
                if ((now -lastSystem)>200) {
                    lastSystem=now;
                    yield();                        // this "system-yield", NOT "task-Yield" ! Without: WDT !!!
                }
            } // end critical

        }


    }
}



void SchedulerClass::block() {
    current->state=BLOCKED;
}


void SchedulerClass::block(int id) {
    Tasks[id]->state=BLOCKED;
}

void SchedulerClass::resume(int id) {
    Tasks[id]->state=READY;
}
